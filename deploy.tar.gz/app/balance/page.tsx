'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Wallet,
  Plus,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  TrendingDown,
  FileText,
  Loader2,
  RefreshCw,
} from 'lucide-react';
import Navbar from '@/components/Navbar';
import VoiceAssistant from '@/components/VoiceAssistant';
import { WeeklyBalance } from '@/lib/types';
import toast from 'react-hot-toast';

export default function BalancePage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [balances, setBalances] = useState<WeeklyBalance[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [formData, setFormData] = useState({
    weekStart: '',
    weekEnd: '',
    openingBalance: '',
    closingBalance: '',
    totalIncome: '',
    totalExpenses: '',
    notes: '',
  });

  // Set default week dates
  useEffect(() => {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - dayOfWeek);
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);

    setFormData((prev) => ({
      ...prev,
      weekStart: startOfWeek.toISOString().split('T')[0],
      weekEnd: endOfWeek.toISOString().split('T')[0],
    }));
  }, []);

  const fetchBalances = async () => {
    try {
      const response = await fetch('/api/balance');
      const data = await response.json();
      if (data.success) {
        setBalances(data.data);
      }
    } catch (error) {
      console.error('Fetch balances error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBalances();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/balance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (data.success) {
        toast.success('Weekly balance logged successfully!');
        setFormData((prev) => ({
          ...prev,
          openingBalance: '',
          closingBalance: '',
          totalIncome: '',
          totalExpenses: '',
          notes: '',
        }));
        fetchBalances();
      } else {
        toast.error(data.error || 'Failed to log balance');
      }
    } catch (error) {
      console.error('Submit error:', error);
      toast.error('Failed to log balance');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleVoiceCommand = (data: any, type: string) => {
    if (type === 'balance') {
      setFormData((prev) => ({
        ...prev,
        ...data,
        openingBalance: data.openingBalance?.toString() || prev.openingBalance,
        closingBalance: data.closingBalance?.toString() || prev.closingBalance,
      }));
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(value);
  };

  const netChange =
    (parseFloat(formData.closingBalance) || 0) -
    (parseFloat(formData.openingBalance) || 0);

  return (
    <div className="min-h-screen bg-hitman-gradient">
      <Navbar />

      <main className="pt-20 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="font-hitman text-2xl sm:text-3xl font-bold text-white flex items-center gap-3">
            <Wallet className="w-8 h-8 text-hitman-gold" />
            WEEKLY BALANCE
          </h1>
          <p className="text-gray-400 mt-1">Track your weekly financial position</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Form Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="agent-card"
          >
            <h2 className="font-hitman text-lg font-bold text-white mb-6 flex items-center gap-2">
              <Plus className="w-5 h-5 text-hitman-gold" />
              NEW WEEKLY ENTRY
            </h2>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Week Range */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-2 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Week Start
                  </label>
                  <input
                    type="date"
                    name="weekStart"
                    value={formData.weekStart}
                    onChange={handleChange}
                    required
                    className="netflix-input"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-2 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Week End
                  </label>
                  <input
                    type="date"
                    name="weekEnd"
                    value={formData.weekEnd}
                    onChange={handleChange}
                    required
                    className="netflix-input"
                  />
                </div>
              </div>

              {/* Balances */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-2">
                    Opening Balance
                  </label>
                  <input
                    type="number"
                    name="openingBalance"
                    value={formData.openingBalance}
                    onChange={handleChange}
                    required
                    placeholder="0.00"
                    className="netflix-input text-lg"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-2">
                    Closing Balance
                  </label>
                  <input
                    type="number"
                    name="closingBalance"
                    value={formData.closingBalance}
                    onChange={handleChange}
                    required
                    placeholder="0.00"
                    className="netflix-input text-lg"
                  />
                </div>
              </div>

              {/* Net Change Preview */}
              {formData.openingBalance && formData.closingBalance && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`p-4 rounded-xl text-center ${
                    netChange >= 0
                      ? 'bg-green-500/20 border border-green-500/30'
                      : 'bg-red-500/20 border border-red-500/30'
                  }`}
                >
                  <p className="text-sm text-gray-400 mb-1">Net Change</p>
                  <p
                    className={`text-2xl font-bold flex items-center justify-center gap-2 ${
                      netChange >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}
                  >
                    {netChange >= 0 ? (
                      <TrendingUp className="w-6 h-6" />
                    ) : (
                      <TrendingDown className="w-6 h-6" />
                    )}
                    {netChange >= 0 ? '+' : ''}
                    {formatCurrency(netChange)}
                  </p>
                </motion.div>
              )}

              {/* Income & Expenses */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-2 flex items-center gap-2">
                    <ArrowUpRight className="w-4 h-4 text-green-400" />
                    Total Income
                  </label>
                  <input
                    type="number"
                    name="totalIncome"
                    value={formData.totalIncome}
                    onChange={handleChange}
                    placeholder="0.00"
                    className="netflix-input"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-2 flex items-center gap-2">
                    <ArrowDownRight className="w-4 h-4 text-red-400" />
                    Total Expenses
                  </label>
                  <input
                    type="number"
                    name="totalExpenses"
                    value={formData.totalExpenses}
                    onChange={handleChange}
                    placeholder="0.00"
                    className="netflix-input"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-gray-400 text-sm mb-2 flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Notes (Optional)
                </label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                  rows={3}
                  placeholder="Weekly summary or notes..."
                  className="netflix-input resize-none"
                />
              </div>

              {/* Submit Button */}
              <motion.button
                type="submit"
                disabled={isSubmitting}
                className="w-full mobile-btn bg-hitman-gold/20 text-hitman-gold border-2 border-hitman-gold hover:bg-hitman-gold hover:text-hitman-black mt-6"
                whileTap={{ scale: 0.98 }}
              >
                {isSubmitting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Plus className="w-5 h-5" />
                    LOG WEEKLY BALANCE
                  </>
                )}
              </motion.button>
            </form>
          </motion.div>

          {/* Recent Balances */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="agent-card"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-hitman text-lg font-bold text-white">
                WEEKLY HISTORY
              </h2>
              <button
                onClick={fetchBalances}
                disabled={isLoading}
                className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-hitman-gunmetal transition-colors"
              >
                <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            <div className="space-y-4 max-h-[600px] overflow-y-auto">
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-8 h-8 text-hitman-gold animate-spin" />
                </div>
              ) : balances.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Wallet className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No weekly balances logged yet</p>
                </div>
              ) : (
                balances.map((balance, index) => (
                  <motion.div
                    key={balance.id || index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-hitman-black/50 rounded-xl p-5 border border-hitman-gunmetal hover:border-hitman-gold/50 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-sm text-gray-500">
                        {balance.weekStart} - {balance.weekEnd}
                      </span>
                      <span
                        className={`text-lg font-bold flex items-center gap-1 ${
                          balance.netChange >= 0 ? 'text-green-400' : 'text-red-400'
                        }`}
                      >
                        {balance.netChange >= 0 ? (
                          <TrendingUp className="w-5 h-5" />
                        ) : (
                          <TrendingDown className="w-5 h-5" />
                        )}
                        {balance.netChange >= 0 ? '+' : ''}
                        {formatCurrency(balance.netChange)}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div className="bg-hitman-gunmetal/50 rounded-lg p-3">
                        <p className="text-xs text-gray-500 mb-1">Opening</p>
                        <p className="text-white font-medium">
                          {formatCurrency(balance.openingBalance)}
                        </p>
                      </div>
                      <div className="bg-hitman-gunmetal/50 rounded-lg p-3">
                        <p className="text-xs text-gray-500 mb-1">Closing</p>
                        <p className="text-white font-medium">
                          {formatCurrency(balance.closingBalance)}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1 text-green-400">
                        <ArrowUpRight className="w-4 h-4" />
                        {formatCurrency(balance.totalIncome)}
                      </div>
                      <div className="flex items-center gap-1 text-red-400">
                        <ArrowDownRight className="w-4 h-4" />
                        {formatCurrency(balance.totalExpenses)}
                      </div>
                    </div>

                    {balance.notes && (
                      <p className="text-gray-500 text-sm mt-3 italic">
                        {balance.notes}
                      </p>
                    )}
                  </motion.div>
                ))
              )}
            </div>
          </motion.div>
        </div>
      </main>

      {/* Voice Assistant */}
      <VoiceAssistant onCommand={handleVoiceCommand} />
    </div>
  );
}
