import { NextRequest, NextResponse } from 'next/server';
import { appendWeeklyBalance, getWeeklyBalances } from '@/lib/google-sheets';
import { verifyToken } from '@/lib/auth';
import { notifyBalance } from '@/lib/n8n-webhook';
import { WeeklyBalance } from '@/lib/types';

// Get all weekly balances
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('auth-token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json(
        { success: false, error: 'Invalid token' },
        { status: 401 }
      );
    }

    const balances = await getWeeklyBalances();
    return NextResponse.json({ success: true, data: balances });
  } catch (error) {
    console.error('Get balances error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Add weekly balance entry
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('auth-token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json(
        { success: false, error: 'Invalid token' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const {
      weekStart,
      weekEnd,
      openingBalance,
      closingBalance,
      totalIncome,
      totalExpenses,
      notes,
    } = body;

    // Validate required fields
    if (
      !weekStart ||
      !weekEnd ||
      openingBalance === undefined ||
      closingBalance === undefined
    ) {
      return NextResponse.json(
        { success: false, error: 'Required fields are missing' },
        { status: 400 }
      );
    }

    const netChange = closingBalance - openingBalance;

    const balance: WeeklyBalance = {
      weekStart,
      weekEnd,
      openingBalance: parseFloat(openingBalance),
      closingBalance: parseFloat(closingBalance),
      totalIncome: parseFloat(totalIncome || 0),
      totalExpenses: parseFloat(totalExpenses || 0),
      netChange,
      notes,
      userId: decoded.userId,
      userName: decoded.username,
      createdAt: new Date().toISOString(),
    };

    const success = await appendWeeklyBalance(balance);

    if (!success) {
      return NextResponse.json(
        { success: false, error: 'Failed to save balance to Google Sheets' },
        { status: 500 }
      );
    }

    // Send WhatsApp notification
    await notifyBalance(decoded.username, closingBalance, notes || '');

    return NextResponse.json({ success: true, data: balance });
  } catch (error) {
    console.error('Add balance error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
