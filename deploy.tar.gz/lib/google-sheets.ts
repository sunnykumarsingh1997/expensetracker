import { google } from 'googleapis';
import { DailyExpense, DailyIncome, WeeklyBalance } from './types';

const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];

// Sheet names/tabs
const SHEETS = {
  DAILY_EXPENSES: 'Daily Expenses',
  DAILY_INCOME: 'Daily Income',
  WEEKLY_BALANCE: 'Weekly Balance',
  BUDGET_SETTINGS: 'Budget Settings',
  MONTHLY_SUMMARY: 'Monthly Summary',
};

// Get authenticated Google Sheets client
async function getGoogleSheetsClient() {
  const auth = new google.auth.GoogleAuth({
    credentials: {
      client_email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
      private_key: process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    },
    scopes: SCOPES,
  });

  const sheets = google.sheets({ version: 'v4', auth });
  return sheets;
}

// Format date for Google Sheets
function formatDate(date: string): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
}

// Get month name from date
function getMonthName(date: string): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', { month: 'long' });
}

// EXPENSE OPERATIONS
export async function appendExpense(expense: DailyExpense): Promise<boolean> {
  try {
    const sheets = await getGoogleSheetsClient();
    const spreadsheetId = process.env.GOOGLE_SHEETS_ID;

    const values = [
      [
        formatDate(expense.date),
        getMonthName(expense.date),
        expense.category,
        expense.description,
        expense.amount,
        expense.paymentMode,
        expense.needWant,
        expense.paperlessLink || expense.image || '',
      ],
    ];

    await sheets.spreadsheets.values.append({
      spreadsheetId,
      range: `'${SHEETS.DAILY_EXPENSES}'!A:H`,
      valueInputOption: 'USER_ENTERED',
      insertDataOption: 'INSERT_ROWS',
      requestBody: { values },
    });

    return true;
  } catch (error) {
    console.error('Error appending expense:', error);
    return false;
  }
}

export async function getExpenses(): Promise<DailyExpense[]> {
  try {
    const sheets = await getGoogleSheetsClient();
    const spreadsheetId = process.env.GOOGLE_SHEETS_ID;

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `'${SHEETS.DAILY_EXPENSES}'!A2:H`,
    });

    const rows = response.data.values || [];
    return rows.map((row, index) => ({
      id: `expense-${index}`,
      date: row[0] || '',
      month: row[1] || '',
      category: row[2] || '',
      description: row[3] || '',
      amount: parseFloat(row[4]) || 0,
      paymentMode: row[5] || '',
      needWant: (row[6] as 'NEED' | 'WANT') || 'NEED',
      image: row[7] || '',
      userId: '',
      userName: '',
    }));
  } catch (error) {
    console.error('Error fetching expenses:', error);
    return [];
  }
}

// INCOME OPERATIONS
export async function appendIncome(income: DailyIncome): Promise<boolean> {
  try {
    const sheets = await getGoogleSheetsClient();
    const spreadsheetId = process.env.GOOGLE_SHEETS_ID;

    const values = [
      [
        formatDate(income.date),
        getMonthName(income.date),
        income.source,
        income.amount,
        income.receivedIn,
        income.receivedFrom,
        income.notes || '',
        income.paperlessLink || income.image || '',
      ],
    ];

    await sheets.spreadsheets.values.append({
      spreadsheetId,
      range: `'${SHEETS.DAILY_INCOME}'!A:H`,
      valueInputOption: 'USER_ENTERED',
      insertDataOption: 'INSERT_ROWS',
      requestBody: { values },
    });

    return true;
  } catch (error) {
    console.error('Error appending income:', error);
    return false;
  }
}

export async function getIncomes(): Promise<DailyIncome[]> {
  try {
    const sheets = await getGoogleSheetsClient();
    const spreadsheetId = process.env.GOOGLE_SHEETS_ID;

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `'${SHEETS.DAILY_INCOME}'!A2:H`,
    });

    const rows = response.data.values || [];
    return rows.map((row, index) => ({
      id: `income-${index}`,
      date: row[0] || '',
      month: row[1] || '',
      source: row[2] || '',
      amount: parseFloat(row[3]) || 0,
      receivedIn: row[4] || '',
      receivedFrom: row[5] || '',
      notes: row[6] || '',
      image: row[7] || '',
      userId: '',
      userName: '',
    }));
  } catch (error) {
    console.error('Error fetching incomes:', error);
    return [];
  }
}

// WEEKLY BALANCE OPERATIONS
export async function appendWeeklyBalance(balance: WeeklyBalance): Promise<boolean> {
  try {
    const sheets = await getGoogleSheetsClient();
    const spreadsheetId = process.env.GOOGLE_SHEETS_ID;

    const values = [
      [
        formatDate(balance.weekStart),
        formatDate(balance.weekEnd),
        balance.openingBalance,
        balance.closingBalance,
        balance.totalIncome,
        balance.totalExpenses,
        balance.netChange,
        balance.notes || '',
      ],
    ];

    await sheets.spreadsheets.values.append({
      spreadsheetId,
      range: `'${SHEETS.WEEKLY_BALANCE}'!A:H`,
      valueInputOption: 'USER_ENTERED',
      insertDataOption: 'INSERT_ROWS',
      requestBody: { values },
    });

    return true;
  } catch (error) {
    console.error('Error appending weekly balance:', error);
    return false;
  }
}

export async function getWeeklyBalances(): Promise<WeeklyBalance[]> {
  try {
    const sheets = await getGoogleSheetsClient();
    const spreadsheetId = process.env.GOOGLE_SHEETS_ID;

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `'${SHEETS.WEEKLY_BALANCE}'!A2:H`,
    });

    const rows = response.data.values || [];
    return rows.map((row, index) => ({
      id: `balance-${index}`,
      weekStart: row[0] || '',
      weekEnd: row[1] || '',
      openingBalance: parseFloat(row[2]) || 0,
      closingBalance: parseFloat(row[3]) || 0,
      totalIncome: parseFloat(row[4]) || 0,
      totalExpenses: parseFloat(row[5]) || 0,
      netChange: parseFloat(row[6]) || 0,
      notes: row[7] || '',
      userId: '',
      userName: '',
    }));
  } catch (error) {
    console.error('Error fetching weekly balances:', error);
    return [];
  }
}

// GET ALL DATA FOR DASHBOARD
export async function getDashboardData() {
  try {
    const [expenses, incomes, balances] = await Promise.all([
      getExpenses(),
      getIncomes(),
      getWeeklyBalances(),
    ]);

    const totalIncome = incomes.reduce((sum, i) => sum + i.amount, 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const currentBalance = totalIncome - totalExpenses;

    const needsTotal = expenses
      .filter((e) => e.needWant === 'NEED')
      .reduce((sum, e) => sum + e.amount, 0);
    const wantsTotal = expenses
      .filter((e) => e.needWant === 'WANT')
      .reduce((sum, e) => sum + e.amount, 0);

    return {
      expenses,
      incomes,
      balances,
      stats: {
        totalIncome,
        totalExpenses,
        currentBalance,
        savingsRate: totalIncome > 0 ? ((totalIncome - totalExpenses) / totalIncome) * 100 : 0,
        needsTotal,
        wantsTotal,
        needsPercentage: totalExpenses > 0 ? (needsTotal / totalExpenses) * 100 : 0,
        wantsPercentage: totalExpenses > 0 ? (wantsTotal / totalExpenses) * 100 : 0,
      },
    };
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    return null;
  }
}

// Initialize sheets with headers if they don't exist
export async function initializeSheets(): Promise<boolean> {
  try {
    const sheets = await getGoogleSheetsClient();
    const spreadsheetId = process.env.GOOGLE_SHEETS_ID;

    // Check if sheets exist and have headers
    const sheetsToInit = [
      {
        name: SHEETS.DAILY_EXPENSES,
        headers: ['DATE', 'MONTH', 'CATEGORY', 'PAYMENT FOR (DESCRIPTION)', 'AMOUNT', 'PAYMENT MODE', 'NEED/WANT', 'IMAGE'],
      },
      {
        name: SHEETS.DAILY_INCOME,
        headers: ['DATE', 'MONTH', 'SOURCE', 'AMOUNT', 'RECEIVED IN', 'RECEIVED FROM', 'NOTES', 'IMAGE'],
      },
      {
        name: SHEETS.WEEKLY_BALANCE,
        headers: ['WEEK START', 'WEEK END', 'OPENING BALANCE', 'CLOSING BALANCE', 'TOTAL INCOME', 'TOTAL EXPENSES', 'NET CHANGE', 'NOTES'],
      },
    ];

    for (const sheet of sheetsToInit) {
      try {
        const response = await sheets.spreadsheets.values.get({
          spreadsheetId,
          range: `'${sheet.name}'!A1:H1`,
        });

        if (!response.data.values || response.data.values.length === 0) {
          await sheets.spreadsheets.values.update({
            spreadsheetId,
            range: `'${sheet.name}'!A1:H1`,
            valueInputOption: 'RAW',
            requestBody: { values: [sheet.headers] },
          });
        }
      } catch (error) {
        // Sheet might not exist, try to create it
        console.log(`Sheet ${sheet.name} might not exist, skipping header initialization`);
      }
    }

    return true;
  } catch (error) {
    console.error('Error initializing sheets:', error);
    return false;
  }
}
